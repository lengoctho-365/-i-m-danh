﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Forms.v1;
using Google.Apis.Forms.v1.Data;
using Google.Apis.Services;
using QRCoder;
using System;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static QRCoder.PayloadGenerator;

// Define an alias for Google Form to resolve ambiguity
using GoogleForm = Google.Apis.Forms.v1.Data.Form;

namespace WindowsFormsApp1
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            // Step 1: Create Google Form and retrieve the URL
            string formUrl = await CreateGoogleForm();

            // Step 2: Generate QR code for the form URL
            if (!string.IsNullOrEmpty(formUrl))
            {
                Url generator = new Url(formUrl);
                string payload = generator.ToString();

                QRCodeGenerator qrGenerator = new QRCodeGenerator();
                QRCodeData qrCodeData = qrGenerator.CreateQrCode(payload, QRCodeGenerator.ECCLevel.Q);
                QRCode qrCode = new QRCode(qrCodeData);
                pictureBox1.Image = qrCode.GetGraphic(5);

                MessageBox.Show("Form created and QR code generated!", "Success");
            }
            else
            {
                MessageBox.Show("Failed to create the Google Form.", "Error");
            }
        }

        private async Task<string> CreateGoogleForm()
        {
            try
            {
                // Use a traditional using block to handle file stream disposal
                UserCredential credential;
                using (var stream = new FileStream("credentials.json", FileMode.Open, FileAccess.Read))
                {
                    credential = await GoogleWebAuthorizationBroker.AuthorizeAsync(
                        GoogleClientSecrets.FromStream(stream).Secrets,
                        new[] { FormsService.Scope.FormsBody },
                        "user",
                        CancellationToken.None);
                }

                // Initialize the Forms API service
                FormsService service = new FormsService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = "Google Forms API Example",
                });

                // Define Google Form details using the alias
                var googleForm = new GoogleForm
                {
                    Info = new Info { Title = "Sample Form", Description = "This is a sample form created via API." }
                };

                // Create the Google Form
                var request = service.Forms.Create(googleForm);
                GoogleForm createdForm = await request.ExecuteAsync();

                // Return the form URL
                return createdForm.ResponderUri;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
                return null;
            }
        }
    }
}
